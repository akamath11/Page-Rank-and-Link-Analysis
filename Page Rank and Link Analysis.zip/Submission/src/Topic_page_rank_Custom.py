from __future__ import division
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix
import os



f = open ('transition.txt', 'r')
l = []
l = [line.split() for line in f]
l=np.array(l).astype(float)-1
l_df=pd.DataFrame(l)

N=(np.array(l_df[0])[-1]+1).astype('int')
  
#Initialization
maxchange=0.0000000001
dp=1/N
r = np.matrix(np.ones(N)*dp)
r = np.transpose(r).astype('float64')

B=np.ones(N)*0.7
l_array=np.array(l_df[1])
for i in range(N):
    if i not in l_array:
        B[i]=0

l_num=0

values=np.zeros(N)
keys=range(N)
di=dict(zip(keys, values))

for i in range(len(l)):
    di[l[i][1]]+=1      #Counting total number of entries in a column
    
for i in range(len(l)):
    l[i][2]+=1
    l[i][2]=float(l[i][2]/di[l[i][1]])
            
l_df=pd.DataFrame(l)

Z=l_df[2]
M=coo_matrix((Z,(l_df[1],l_df[0])),shape=(N,N))

##Finding topic of nodes from doc topic file
f1 = open ('doc_topics.txt', 'r')
d_topic = []
d_topic = [line.split() for line in f1]
d_topic=np.array(d_topic).astype(int)
dtsr=pd.DataFrame(d_topic)
dtsr=dtsr.groupby(0)[1].apply(list)
##d__df=pd.DataFrame(l)

#Finding query topic probabilities 
f2 = open ('query_topic.txt', 'r')
q_topic = []
q_topic = [line.split() for line in f2]
q_topic=np.array(q_topic)
num_topics=int(q_topic.shape[1])-2
qtsr=pd.DataFrame(q_topic)
query = qtsr[0].map(str) + qtsr[1]    
qtsr.drop([0,1],axis=1,inplace=True)
qtsr.columns=range(1,num_topics+1)
for i in qtsr:
    qtsr[i]=qtsr[i].str.split(':').str.get(1)
qtsr['query']=query

num_topics=len(qtsr.columns)-1
scores=np.zeros(num_topics)
for i in range(1,num_topics+1):
    for j in range(1,len(dtsr)+1):
        if(i in dtsr[j]):
            scores[i-1]+=1
       

import time
start_time = time.time()

fout = open('test.txt', 'w')
#query specific, loop over all queries
for filename in os.listdir('Query Scores'):
    f = open ('Query Scores/'+filename, 'r')
    qid_str=filename.split('.')[0]
    q = []
    q = [line.split() for line in f]
    q=np.array(q)
    q_df=pd.DataFrame(q)
    q_df=q_df[[2,4]]
    q_df[2]=q_df[2].astype(int)
    q_df[4]=q_df[4].astype(float)
    q_df.sort(2,inplace=True)
    q_df.set_index(2,inplace=True)
    qid=int(filename.split('.')[0].split('-')[0]+filename.split('.')[0].split('-')[1])
    qtrial=qtsr[qtsr['query']==str(qid)]
    qtrial.drop('query',axis=1,inplace=True)
    qt=(qtrial.values).astype(float).flatten()    
    
    


#add weights to each doc
    #rq values for each documents- Tells by how much probability to teleport to each doc    
    weights=np.zeros(r.shape)
    for i in range(len(qt)):
        for j in range(1,len(dtsr)+1):
            if(i+1 in dtsr[j]):
                weights[j-1]+=qt[i]/scores[i]
    weight_left=1-weights.sum()
    weights=weights+weight_left/len(dtsr)

    change=100
    while(change>maxchange):
        old_r=r    
        A=M*r
        C=np.transpose(np.matrix(B))
        r=np.array(A)*np.array(C)
        
        waste=1-np.sum(r)
        distribute=waste*weights
        r=r+distribute
        new_r=r
        change=np.linalg.norm(new_r-old_r)
    
    rank_scores=np.sort(np.array(new_r).flatten())[::-1]    #For printing into file
    rank_scores1=np.array(new_r).flatten()  #For document ranking
    ranked_list=np.array(new_r).flatten().argsort()[::-1]
    

    final_score=[]
    
    retrieval_num=1
    for index in q_df.index:
        relevance=np.exp(float(q_df.loc[index]))
        popularity=rank_scores1[index-1]
        if(retrieval_num<0.2*len(q_df.index)):
            final_score.append(np.log(0.5*relevance+0.5*popularity))
        else:
            final_score.append(np.log(0.8*relevance+0.2*popularity))
        
        retrieval_num=retrieval_num+1
        
    q_df['final_scores']=final_score
    q_df.sort(columns=['final_scores'],inplace=True,ascending=False)
    
        
    for i in range(len(q_df)):
        index=q_df.index[i]
        l=[qid_str,'Q0',index,i+1,q_df.loc[index]['final_scores'],'run-1']
        l1=str(l).replace("'",'')
        l2=l1.replace(",",'')
        fout.write(l2[1:-1]+'\n')
    q_df.drop('final_scores',axis=1,inplace=True)

fout.close()
print("--- %s seconds ---" % (time.time() - start_time))   
        